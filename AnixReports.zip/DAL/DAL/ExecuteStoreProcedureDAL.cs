﻿using DAL.IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL.Repository;
using System.Collections;
using System.Data;
using System.Configuration;

namespace DAL.DAL
{
    public class ExecuteStoreProcedureDAL : AdoRepository<dynamic>, IExecuteStoreProcedureDAL
    {
        #region ExecuteStoreProcedures
        public dynamic ExecuteStoreProcedures(SQLModel objSqlModel)
        {
            List<dynamic> list = new List<dynamic>();
            Hashtable param = new Hashtable();
            if (objSqlModel.Params != null)
            {
                foreach (var item in objSqlModel.Params)
                {
                    param.Add(item.Name, item.Value);
                }
            }
            string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings[objSqlModel.Database]);
            DataSet ds = ExecuteStoredProcedureDS(param, objSqlModel.ProcedureName, ConnectionString);
            return ds;
        }
        #endregion

    }
}
