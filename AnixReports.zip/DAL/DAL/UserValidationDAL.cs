﻿using DAL.IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL.DAL
{
    public class UserValidationDAL : IUserValidationDAL
    {
        public UserModel ValidateUser(UserModel objModel)
        {
            UserModel objUserModel = new UserModel();
            using (AnixEntities _dataBaseContext = new AnixEntities())
            {
                var dataResult = _dataBaseContext.Users.FirstOrDefault(user=>user.USER_NAME == objModel.Username && user.PASSWORD==objModel.Password);
                if (dataResult != null) {
                    objUserModel.Username = dataResult.USER_NAME;
                    objUserModel.Email = dataResult.EMAIL_ADDRESS;
                    objUserModel.Role = "Admin";
                }
            }
            return objUserModel;
            //throw new NotImplementedException();
        }
    }
}
