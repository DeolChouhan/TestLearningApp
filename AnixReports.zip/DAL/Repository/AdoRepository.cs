﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repository
{
    public abstract class AdoRepository<T1> where T1 : class
    {
        string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["RI"]);
        #region ExecuteStoredProcedureDT
        public DataTable ExecuteStoredProcedureDT(Hashtable param, string StoredProcedure)
        {
            DataTable dt = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(ConnectionString))
                using (SqlCommand cmd = new SqlCommand(StoredProcedure, conn))
                {
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    ICollection keys = param.Keys;

                    foreach (string key in keys)
                    {
                        adapt.SelectCommand.Parameters.AddWithValue(key, param[key]);
                    }


                    dt = new DataTable();
                    adapt.Fill(dt);


                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }
        #endregion

        #region ExecuteStoredProcedureDS
        public DataSet ExecuteStoredProcedureDS(Hashtable param, string StoredProcedure, string _ConnectionString)
        {
            DataSet ds = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(_ConnectionString))
                using (SqlCommand cmd = new SqlCommand(StoredProcedure, conn))
                {
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    ICollection keys = null;
                    if (param != null)
                    {
                        keys = param.Keys;
                    }
                    if (keys != null)
                    {
                        foreach (string key in keys)
                        {
                            adapt.SelectCommand.Parameters.AddWithValue("@" + key, param[key]);
                        }
                    }
                    ds = new DataSet();
                    adapt.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        #endregion

        #region ExecuteInlineQueries
        public DataSet ExecuteInlineQueries(Hashtable param, string query, string _ConnectionString)
        {
            DataSet ds = null;
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(_ConnectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                   // adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    ICollection keys = null;
                    if (param != null)
                    {
                        keys = param.Keys;
                    }
                    if (keys != null)
                    {
                        foreach (string key in keys)
                        {
                            adapt.SelectCommand.Parameters.AddWithValue("@" + key, param[key]);
                        }
                    }
                    ds = new DataSet();
                    adapt.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        #endregion

        #region ExecuteGenericSP
        public StringBuilder ExecuteGenericSP(Hashtable param, string StoredProcedure)
        {
            var jsonResult = new StringBuilder();
            SqlConnection conn = null;
            try
            {
                using (conn = new SqlConnection(ConnectionString))
                using (SqlCommand cmd = new SqlCommand(StoredProcedure, conn))
                {

                    conn.Open();
                    var reader = cmd.ExecuteReader();
                    if (!reader.HasRows)
                    {
                        jsonResult.Append("[]");
                    }
                    else
                    {
                        while (reader.Read())
                        {
                            jsonResult.Append(reader.GetValue(0).ToString());
                        }
                    }

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return jsonResult;
        }
        #endregion

        #region ConvertDataTable
        public static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        #endregion

        #region GetItem
        public static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
        #endregion
    }
}
