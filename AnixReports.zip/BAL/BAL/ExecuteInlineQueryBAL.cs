﻿using BAL.IBAL;
using DAL.IDAL;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.BAL
{
    public class ExecuteInlineQueryBAL: IExecuteInlineQueryBAL
    {

        private IExecuteInlineQueryDAL _objExecuteInlineQueryDAL;
        public ExecuteInlineQueryBAL(IExecuteInlineQueryDAL objExecuteInlineQueryDAL)
        {
            _objExecuteInlineQueryDAL = objExecuteInlineQueryDAL;
        }
        public dynamic ExecuteInlineQuery(SQLModel objSqlModel)
        {
            return _objExecuteInlineQueryDAL.ExecuteInlineQuery(objSqlModel);
        }
    }
}

