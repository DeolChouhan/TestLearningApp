export const environment = {
  production: false,
  ApiURL: "http://3.134.78.237:8082/",
  Database: "RI"
};
