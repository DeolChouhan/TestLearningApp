export const environment = {
  production: false,
  ApiURL: "http://localhost:2206/",
  Database: "RI",
};
