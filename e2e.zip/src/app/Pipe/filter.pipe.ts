import { Pipe, PipeTransform } from '@angular/core';
import { isNullOrUndefined } from 'util';
@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  /**
   * Pipe for searching the data for the two level 
   * in side bar
   */
  transform(items: any[], searchText: string): any[] {
    const arrayData: any = [];
    if (!items) return [];
    if (!searchText) return items;
    searchText = searchText.toLowerCase();
    items.filter(it => {
       if (!isNullOrUndefined(it.Name) && it.Name !== '' ) {
          if (it.Name.toLowerCase().indexOf(searchText) > -1 ) {
            arrayData.push(it);
          }
        }

        if (!isNullOrUndefined(it.Title) && it.Title !== '' ) {
          if (it.Title.toLowerCase().indexOf(searchText) > -1 ) {
           const data = arrayData.filter(itm => itm.Id === it.Id);
           if(data.length === 0) {
            arrayData.push(it);
           }
          }
        }
    });
    return arrayData;
  }
}
