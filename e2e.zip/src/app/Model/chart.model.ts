import { IStyles } from './style.model';
import { IAxis } from './axis.model';
import { IDataSource } from './datasource.model';
import { IPanel } from './panel.model';
import { ILegend } from './legend.model';
import { ITable } from './table.model';
export interface IChart {
  ID:number;
  Heading: string;
  Name: string;
  Axis: IAxis;
  Table: ITable;
  DataSource: IDataSource;
  Styles: IStyles;
  Index: number;
  TabID: string;
  Panel: IPanel;
  Legend: ILegend;
  Description: string
}

export class Chart implements IChart {
   public TabID:string = '0';

  constructor(public Name: string, public Axis: IAxis, public Table:ITable,
    public DataSource: IDataSource, public Heading: string,
    public Styles: IStyles, public Index: number, public Panel: IPanel,public Legend: ILegend,public ID:number = 0,public Description) {

  }
}
