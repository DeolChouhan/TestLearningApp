export interface IPanel{
  PanalWidth:string;
  PanalHeight:string;
  PanalLeft:string;
  PanalTop:string;
}

export class Panel implements IPanel{
  public PanalWidth:string = '400px';
  public PanalHeight:string = '300px';
  public PanalLeft:string = '0px';
  public PanalTop:string = '0px';
   constructor() {

   }
 }
