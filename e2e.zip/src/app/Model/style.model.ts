export interface IStyles {
  color: Array<string>;
  borderColor: Array<string>;
  colorBar: Array<string>;
  borderColorBar: Array<string>;
  colorLine: Array<string>;
  borderColorLine: Array<string>;
  borderWidth: number;
  fill: boolean;

  PanalWidth:string;
  PanalHeight:string;
  PanalLeft:string;
  PanalTop:string;
}

export class Styles implements IStyles {
  public color: Array<string> = [];
  public borderColor: Array<string> = [];
  public colorBar: Array<string> = [];
  public borderColorBar: Array<string> = [];
  public colorLine: Array<string> = [];
  public borderColorLine: Array<string> = [];
  public borderWidth = 3;
  public fill = true;

  public PanalWidth:string = '400px';
  public PanalHeight:string = '300px';
  public PanalLeft:string = '0px';
  public PanalTop:string = '0px';
  constructor() {}
}
