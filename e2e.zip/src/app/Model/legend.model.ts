export interface ILegend{
  Legend: boolean;
  LegendPosition: string;
  LegendColor: string;
  LegendFontSize: number;
  }

export class Legend implements ILegend{
 public Legend: boolean = true;
 public LegendPosition: string = 'top';
 public LegendColor: string = 'black';
 public LegendFontSize: number = 12;
  constructor() {

  }
}
