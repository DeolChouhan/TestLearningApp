export interface ITable{
    Column: Array <string>;
    TableStyle:string;
    HeaderStyle:string;
    BorderStyle:string;
  }
  
  export class Table implements ITable{
   public Column: Array <string> = [];
   public TableStyle: string = 'table';
   public HeaderStyle: string = 'thead-light';
   public BorderStyle: string = '';
    constructor() {
  
    }
  }
  