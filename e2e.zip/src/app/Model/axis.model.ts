export interface IAxis{
  XAxis: string;
  YAxis: Array <string>;
  YAxisBar: Array <string>;
  YAxisLine: Array <string>;
  XAxisDisplay: boolean;
  YAxisDisplay: boolean;
  XAxisFontSize: number;
  YAxisFontSize: number;
  XAxisFontColor: string;
  YAxisFontColor: string;
  AggregateType:string;
  xAxisStack: boolean;
  yAxisStack: boolean;
}

export class Axis implements IAxis{
 public XAxis: string;
 public YAxis: Array <string> = [];
 public YAxisBar: Array <string> = [];
 public YAxisLine: Array <string> = [];
 public  XAxisDisplay: boolean = true;
 public YAxisDisplay: boolean = true;
 public XAxisFontSize: number = 10;
 public YAxisFontSize: number = 10;
 public XAxisFontColor: string = 'black';
 public YAxisFontColor: string = 'black';
 public AggregateType: string = 'Count';
 public xAxisStack: boolean = false;
 public yAxisStack: boolean = false;
  constructor() {

  }
}
