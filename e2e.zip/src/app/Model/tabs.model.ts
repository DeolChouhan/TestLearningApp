export interface ITabs{
  cinchyid:string;
  TabName: string;
  ID: string;
}

export class Tabs implements ITabs{
  public cinchyid:string = "0";
  public TabName: string;
  public ID: string
}
