export interface IReport{
  ID:number,
  Name: string;
  DataSource: string,
  DataSourceID: number,
  JSON: string
}

export class Report implements IReport {
  constructor (public ID:number,public Name: string, public DataSource: string, public DataSourceID:number, public JSON:string='') {

  }
}
