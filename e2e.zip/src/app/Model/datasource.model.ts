
export interface IDataSource {
  Domain: string;
  Query: string;
  DataSet: any;
  SourceId: Number;
}

export class DataSource implements IDataSource {
  public Domain: string;
   public Query: string;
   public DataSet: Array<any>;
   public SourceId: Number;
  constructor() {

  }
}
