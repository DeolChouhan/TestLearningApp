import { Tabs } from './../Model/tabs.model';
import { IChart,Chart } from './../Model/chart.model';
import { Report, IReport } from './../Model/report.model';
import { Component, Renderer2, ViewChild } from '@angular/core';
import { ITabs } from '../Model/tabs.model';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { IPanel } from '../Model/panel.model';
import html2pdf from 'html2pdf.js';
declare const jQuery: any;
@Component({
  selector: 'app-report-view',
  templateUrl: './report-view.component.html',
  providers: [
  ]
})
export class ReportViewComponent {
  chartsArray: Array<IChart> = [];
  reportObject: IReport;
  editableConfig: IChart;
  selectedTab: string = '1';
  tabs: Array<ITabs> = [];
  @ViewChild('contentToConvert') contentToConvert;
  constructor(  private router: Router) {}
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnInit() {
    debugger;
    let data = JSON.parse(localStorage.getItem('ReportData'));
    this.tabs.push({ cinchyid:"0", ID: '1', TabName: 'tab 1'});
    this.reportObject = new Report(
      data.ID || 0,
      data.Name,
      data.DataSource,
      data.DataSourceID,
      data.JSON
    );
    this.chartsArray = JSON.parse(data.JSON);
    if(this.reportObject.ID !== 0){
      this.tabs = JSON.parse(localStorage.getItem("ReportTabsData"));
    }
    jQuery(document).ready(function($) {
      $(".burger-menu").on("click", "a", function() {
        $(".profile-bar")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("left-expand");
      });

      $(".burger-menu1").on("click", "a", function() {
        $(".chart-slide")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("right-expand");
      });
    });
  }
  editReport() {
    this.router.navigateByUrl('/manage-report');
  }
 //#region export tab to PDF
 public ExportToPDF() {
      const element = document.getElementById("contentConvert");
      const opt = {
        margin: 1,
        filename: "myfile.pdf",
        image: { type: "jpeg", quality: 1 },
        html2canvas: { scale: 2 },
        jsPDF: {
          unit: "in",
          format: "letter",
          orientation: "portrait"
        }
      };

      // New Promise-based usage:
      html2pdf()
        .from(element)
        .set(opt)
        .save();
}
//#endregion


}
