import { Component} from '@angular/core';
import { environment } from 'src/environments/environment';
declare const jQuery: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'Anix-BI';
  fullScreenHeight = 400;
  isLoggedIn = false;
  constructor() {
      /**
       * Get the Window Height From the Parent Window
       */
      // window.addEventListener('message', this.receiveMessage, false);
      // this._cinchyService.login().then(response => {
      //   this._cinchyService.getUserIdentity().subscribe(
      //     userId => {
      //       if (userId != null) {
      //         this.isLoggedIn = true;
      //         // get company list for dropdown
      //         if (localStorage.getItem('fullScreenHeight')) {
      //           this.fullScreenHeight = parseInt(localStorage.getItem('fullScreenHeight'));
      //         }
      //         var elements = document.getElementsByClassName('full-height-element');
      //         for (var i = 0; i < elements.length; i++) {
      //           elements[i]['style'].height = this.fullScreenHeight + 'px';
      //         }
      //         let navTablesEl = document.getElementById('navTables');
      //         if (navTablesEl) {
      //           navTablesEl['style'].height = (this.fullScreenHeight - 88) + 'px';
      //         }
      //       }
      //     }
      //   );
      // }).catch(error => {
      //   console.error('Login Failed');
      // });
    }

  //#region Get Full length of the screen
  // get Full Screen height of screen

  //#endregion

}
