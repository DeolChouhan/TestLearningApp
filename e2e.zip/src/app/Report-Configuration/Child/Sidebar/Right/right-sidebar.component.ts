import { IChart } from './../../../../Model/chart.model';
import { Component, EventEmitter, Output, Input } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ChartConfigurationModalComponent } from 'src/app/Chart-Configuration-Modal/chart-configuration-modal.component';
import { MatDialog } from '@angular/material';
@Component({
  selector: 'app-right-sidebar',
  templateUrl: './right-sidebar.component.html',
  providers: [
  ]
})
export class RightComponent {
  //#region Out-Put and Input Events
  @Output() Chart = new EventEmitter();
  @Input('editableConfig')
  public editableConfig: any;
  //#endregion
  public chartList = [];
  constructor( public dialog: MatDialog) {
 //   this.getChartsForReports();
  }
  //#region Get charts for reports
  // async getChartsForReports() {
  //   let query = `SELECT [Cinchy Id] as ID, [Chart Name] as Name
  //   FROM [Reporting].[Charts]
  //   WHERE [Deleted] IS NULL`;
  //   this.chartList = (await this.cinchyService
  //     .executeCsql(query, null)
  //     .toPromise()).queryResult.toObjectArray();
  // }
  //#endregion
  //#region Open Chart Configuration Modal
  configureChartMethod(result) {
        this.Chart.emit(result);
  }
  //#endregion
  //#endregion
}
