import { Component, Input } from "@angular/core";
//var $: any;
@Component({
  selector: "app-left-sidebar",
  templateUrl: "./left-sidebar.component.html"
})
export class LeftComponent {
  @Input("openClass")
  public openClass: any;

  ngAfterViewInit() {
    // $("#menu").metisMenu();
  }
}
