import { AnixService } from "./../Service/Anix.Service";
import { Tabs } from "./../Model/tabs.model";
import { IChart, Chart } from "./../Model/chart.model";
import { Report, IReport } from "./../Model/report.model";
import { Component, Renderer2, ViewChild } from "@angular/core";
import { ITabs } from "../Model/tabs.model";
declare const jQuery: any;
import { ToastrService } from "ngx-toastr";
import * as jspdf from "jspdf";
import html2canvas from "html2canvas";
import { ExcelService } from "../Service/excel.service";
import { environment } from "src/environments/environment";
import { IPanel } from "../Model/panel.model";
import html2pdf from "html2pdf.js";
import { ArrayType } from "@angular/compiler";
import { isNullOrUndefined } from "util";
declare var bootbox: any;
@Component({
  selector: "app-report-configuration",
  templateUrl: "./report-configurtation.component.html",
  providers: []
})
export class ReportConfigurationComponent {
  chartsArray: Array<IChart> = [];
  deletechartsArray: Array<number> = [];
  reportObject: IReport;
  editableConfig: IChart;
  selectedTab: string = "1";
  tabs: Array<ITabs> = [];
  panel: IPanel;
  @ViewChild("contentToConvert") contentToConvert;
  constructor(
    private _toastr: ToastrService,
    private renderer: Renderer2,
    private _anixService: AnixService,
    private excelService: ExcelService
  ) {}

  cloneTemplate() {}

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnInit() {
    let data = JSON.parse(localStorage.getItem("ReportData"));
    this.tabs.push({ cinchyid: "0", ID: "1", TabName: "tab 1" });
    this.reportObject = new Report(
      data.ID || 0,
      data.Name,
      data.DataSource,
      data.DataSourceID,
      data.JSON
    );
    this.chartsArray = JSON.parse(data["JSON"]);
    if (this.reportObject.ID !== 0) {
      this.tabs = JSON.parse(localStorage.getItem("ReportTabsData"));
    }
    //Jquery Code
    jQuery(document).ready(function($) {
      $(".burger-menu").on("click", "a", function() {
        $(".profile-bar")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("left-expand");
      });

      $(".burger-menu1").on("click", "a", function() {
        $(".chart-slide")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("right-expand");
      });
    });
    //End
  }
  //#region Create Chart
  addChart(chart: IChart) {
    chart.TabID = this.selectedTab;

    if (chart.Index > -1) {
      this.chartsArray[chart.Index] = chart;
    } else {
      this.chartsArray.push(chart);
    }
  }
  //#endregion
  //#region Remove Chart by index
  removeChart(idx: number) {
    if (this.chartsArray[idx].ID !== 0) {
      this.deletechartsArray.push(this.chartsArray[idx].ID);
    }
    this.chartsArray.splice(idx, 1);
  }
  //#endregion
  //#region Edit Chart by index
  editChart(idx: number) {
    debugger;
    var element = document.body.className;
    // alert();
    if (element.indexOf("settings-open") > -1) {
      document.body.className = "";
    } else {
      document.body.className = document.body.className + " settings-open";
    }
    this.editableConfig = null;
    let that = this;
    setTimeout(() => {
      that.editableConfig = that.chartsArray[idx];
      that.editableConfig.Index = idx;
    }, 1000);
  }
  //#endregion

  //#region set panel postion to chart configuration
  onMoveEnd(event, idx) {
    if (event.x !== 0 && event.y !== 0) {
      this.chartsArray[idx].Styles.PanalLeft = event.x + "px";
      this.chartsArray[idx].Styles.PanalTop = event.y + "px";
    }
  }
  //#endregion

  //#region set panel size to chart configuration
  onResizeStop(event, idx) {
    let cdata = this.chartsArray[idx];
    cdata.Styles.PanalWidth = event.size.width + "px";
    cdata.Styles.PanalHeight = event.size.height + "px";
  }
  //#endregion

  //#region add tab
  addTabs() {
    let randomNUmber = this.getRandomInt(500);
    this.tabs.push({
      cinchyid: "0",
      ID: randomNUmber.toString(),
      TabName: "Tab"
    });
  }
  //#endregion

  //#region generate random int number for tab id
  getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }
  //#endregion

  //#region tab change
  changeSelectedTab(tab: ITabs) {
    this.selectedTab = tab.ID;
  }
  //#endregion

  //#region export tab to PDF
  public ExportToPDF() {
    const element = document.getElementById("contentConvert");
    const opt = {
      margin: 0.3,
      filename: "myfile.pdf",
      image: { type: "jpeg", quality: 0.1 },
      html2canvas: { scale: 2 },
      jsPDF: {
        unit: "in",
        format: "letter",
        orientation: "portrait"
      }
    };

    // New Promise-based usage:
    html2pdf()
      .from(element)
      .set(opt)
      .save();
  }
  //#endregion
  //#region export table data to Excel
  public ExportToExcel(idx) {
    let that: IChart;
    setTimeout(() => {
      that = this.chartsArray[idx];
      that.Index = idx;
      this.excelService.exportAsExcelFile(that.DataSource.DataSet, "Export");
    }, 1000);
  }
  //#endregion
  //#region Save and update report
  SaveReport() {
    debugger;
    console.log(this.chartsArray);
    debugger;
    const query = "SaveUserReports";
    const params = {
      ReportName: this.reportObject.Name,
      ReportJSON: JSON.stringify(this.chartsArray),
      TabJSON: JSON.stringify(this.tabs),
      UserId: 1,
      ReportID: this.reportObject.ID
    };
    this._anixService
      .ExecuteSP(environment.Database, "SaveUserReports", params)
      .subscribe(
        data => {
          this._toastr.success("Report saved Successfully", "Success");
        },
        error => {
          console.log(error);
        }
      );
  }
  //#endregion

  //#region  Remove tabs
  removetabs(idx) {
    this.tabs.splice(idx, 1);
  }
  //#endregion
}
