import { Component, Input, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { environment } from "src/environments/environment";
import { ToastrService } from "ngx-toastr";
import { AnixService } from "../Service/Anix.Service";

@Component({
  selector: "app-confirmation-dialog",
  templateUrl: "./confirmation-dialog.component.html",
  providers: [
  ]
})
export class ConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _anixService: AnixService,
    public dialog: MatDialog,
    private _toastr: ToastrService
  ) {}

  public confirmMessage: string;

  onNoClick(): void {
    this.dialogRef.close();
  }
  onYesClick(): void {
    let query1 = "";
    if (this.data.Type === "Report") {
      query1 = `delete from [UserReportTabs] where [UserReport Id]=${this.data.ID}`;

      this._anixService
        .ExecuteSql(environment.Database, query1, null)
        .subscribe(
          response => {
            query1 = this.deleteReprots(query1);
          },
          error => {
            this._toastr.error("Error Occur while saving report.", "Error");
            return;
          }
        );
    } else if (this.data.Type === "SharedReport") {
      query1 = `delete from UserReportsShared where [Id] =${this.data.ID} Select 1`;
      this._anixService
        .ExecuteSql(environment.Database, query1, null)
        .subscribe(
          response => {
            this._toastr.success("Report Deleted Successfully.", "Success");
            this.dialogRef.close();
          },
          error => {
            this._toastr.error("Error Occur while saving report.", "Error");
            return;
          }
        );
      }


  }

  private deleteReprots(query1: string) {
    query1 = `delete from [dbo].[UserReports]
          where [Id]=${this.data.ID}
          Select 1`;
    this._anixService.ExecuteSql(environment.Database, query1, null).subscribe(
      response => {
        this._toastr.success("Report Deleted Successfully.", "Success");
        this.dialogRef.close();
      },
      error => {
        this._toastr.error("Error Occur while saving report.", "Error");
        return;
      }
    );
    return query1;
  }
}
