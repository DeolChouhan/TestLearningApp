import { AnixService } from "./../Service/Anix.Service";
import { Legend } from "./../Model/legend.model";
import { IStyles, Styles } from "./../Model/style.model";
import { IDataSource, DataSource } from "./../Model/datasource.model";
import { IAxis, Axis } from "./../Model/axis.model";
import { IChart, Chart } from "./../Model/chart.model";
import { Report, IReport } from "./../Model/report.model";
declare const jQuery: any;
import {
  Component,
  OnInit,
  Inject,
  Input,
  EventEmitter,
  Output
} from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from "@angular/material";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
import { Router } from "@angular/router";
import { TableModalComponent } from "../table-modal/table-modal.component";
import { IPanel, Panel } from "../Model/panel.model";
import { ILegend } from "../Model/legend.model";
import { ITable, Table } from "../Model/table.model";
import ChartConfigurationModel from "../Chart/Chart-Configurations/Chart-Configuration.json";
import { ToastrService } from "ngx-toastr";
declare const $: any;

@Component({
  selector: "app-chart-configuration-modal",
  templateUrl: "./chart-configuration-modal.component.html",
  providers: [AnixService]
})
export class ChartConfigurationModalComponent implements OnInit {
  public headingText = "Chart Configuration";
  public btnText = "Configure";
  public dataSetArray: any = [];
  public dataSourceId: any;
  public dataSourceResultArray: any = [];
  public _Axis: IAxis = new Axis();
  public _Table: ITable = new Table();
  public _DataSource: IDataSource = new DataSource();
  public color: string = "red";
  public chartConfiguration: IChart;
  public Heading = "";
  public Description = "";
  public right = "left";
  public ChartStyle: IStyles = new Styles();
  public selectedChart = "";
  public panel: IPanel = new Panel();
  public legend: ILegend = new Legend();
  public systemColor: any = [];
  public selectedChartConfiguration: any;
  public ID: number;
  // tslint:disable-next-line: no-input-rename
  @Output() ChartConfigure = new EventEmitter();
  @Input("EditChartConfig")
  EditChartConfig: IChart;

  public data: any = {
    type: ""
  };

  public chartList: any;
  public counter = 0;

  constructor(
    private _toastr: ToastrService,
    public dialog: MatDialog,
    private _anixService: AnixService
  ) {
    this.getDataSource();
    this.getChartsForReports();
    this.getSystemColor();
  }

  ngOnChanges() {
    console.log(ChartConfigurationModel);
    console.log(ChartConfigurationModel.Configuration["Bar"]);
    if (!isNullOrUndefined(this.EditChartConfig)) {
      this.setEditConfiguration();
    } else {
      this.reset();
    }
  }
  //#region Get Datasource
  async getDataSource() {
    let query = `Select name as Name, name as ID, 'dbo' as Domain from sys.tables`;
    let database = environment.Database;
    var params = null;
    this._anixService.ExecuteSql(database, query, params).subscribe(
      data => {
        console.log(data);
        this.dataSetArray = data;
      },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion
  //#region Get system colors
  async getSystemColor() {
    this.systemColor.push("#CCCCCC");
  }
  //#endregion
  //#region This Method is used to get the Result Of selected DataSource
  async getSelectedDataSourceResult() {
    debugger;
    let dataSet = this.dataSetArray.find(x => x.ID === this.dataSourceId);
    this._DataSource.Query = dataSet.Name;
    this._DataSource.Domain = dataSet.Domain;
    this._DataSource.SourceId = this.dataSourceId;
    var query =
      "Select Top 1 tt.* From [" +
      this._DataSource.Domain +
      "].[" +
      this._DataSource.Query +
      "] as tt";
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        this.dataSourceResultArray = data;
        this._DataSource.DataSet = this.dataSourceResultArray;
      },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion
  //#region Configure Chart
  async configureChart() {
    let index = -1;
    if (!isNullOrUndefined(this.EditChartConfig)) {
      index = this.EditChartConfig.Index;
    }
    let ID = 0;
    if (
      !isNullOrUndefined(this.EditChartConfig) &&
      !isNullOrUndefined(this.EditChartConfig.ID)
    ) {
      ID = this.EditChartConfig.ID;
    }
    if (!isNullOrUndefined(this.Description)) {
      this.Description = this.Description.replace(/'/g, "");
    }
    this.chartConfiguration = new Chart(
      this.data.type,
      this._Axis,
      this._Table,
      this._DataSource,
      this.Heading,
      this.ChartStyle,
      index,
      this.panel,
      this.legend,
      ID,
      this.Description
    );
    this.ChartConfigure.emit(this.chartConfiguration);
    this.reset();
  }
  //#endregion
  //#region Get charts for reports
  async getChartsForReports() {
    let query = `ChartsGet`;
    let database = "RI";
    var params = null;
    this._anixService.ExecuteSP(database, query, params).subscribe(
      data => {
        debugger;
        this.chartList = data;
      },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion

  //#region Add New Chart For Reports
  addChart(type: string) {
    type = type.toLowerCase();
    //Reset the Chart Configuration
    if (!this.EditChartConfig) {
      this.reset();
    } else {
      if (
        this.selectedChart.toLowerCase() === "bar" ||
        this.selectedChart.toLowerCase() === "line"
      ) {
        if (
          type.toLowerCase() === "pie" ||
          type.toLowerCase() === "doughnut" ||
          type.toLowerCase() === "table" ||
          type.toLowerCase() === "bar and line"
        ) {
          this._toastr.error(
            "The selected Chart Type is not compatible with your existing chart, so operation can’t be performed!",
            "Error"
          );
          return;
        }
      } else if (
        this.selectedChart.toLowerCase() === "pie" ||
        this.selectedChart.toLowerCase() === "doughnut"
      ) {
        if (
          type.toLowerCase() === "bar" ||
          type.toLowerCase() === "line" ||
          type.toLowerCase() === "table" ||
          type.toLowerCase() === "bar and line"
        ) {
          this._toastr.error(
            "The selected Chart Type is not compatible with your existing chart, so operation can’t be performed!",
            "Error"
          );
          return;
        }
      } else if (this.selectedChart.toLowerCase() === "table") {
        if (
          type.toLowerCase() === "bar" ||
          type.toLowerCase() === "line" ||
          type.toLowerCase() === "pie" ||
          type.toLowerCase() === "doughnut" ||
          type.toLowerCase() === "bar and line"
        ) {
          this._toastr.error(
            "The selected Chart Type is not compatible with your existing chart, so operation can’t be performed!",
            "Error"
          );
          return;
        }
      } else if (this.selectedChart.toLowerCase() === "bar and line") {
        if (
          type.toLowerCase() === "bar" ||
          type.toLowerCase() === "line" ||
          type.toLowerCase() === "pie" ||
          type.toLowerCase() === "doughnut" ||
          type.toLowerCase() === "table"
        ) {
          this._toastr.error(
            "The selected Chart Type is not compatible with your existing chart, so operation can’t be performed!",
            "Error"
          );
          return;
        }
      }
    }
    //End
    debugger;
    this.selectedChart = type;
    this.selectedChartConfiguration =
      ChartConfigurationModel.Configuration[type];
    console.log(this.selectedChartConfiguration);
    this.OpenChartConfigurationModal(type);
  }
  //#endregion

  //#region Open Chart Configuration Modal
  OpenChartConfigurationModal(type: string): void {
    this.data.type = type.toLowerCase();
    let that = this;
    //jquery Code
    if (this.counter == 0) {
      setTimeout(function() {
        // $(".nav-tabs")
        //   .scrollingTabs({
        //     enableSwiping: true
        //   })
        //   .on("ready.scrtabs", function() {
        $(".tab-content").show();
        // });
        that.counter = 1;
      }, 50);
    }

    //End
  }
  //#endregion
  //#region Add Color/ Assign Values to Y-Axis
  public asignYAxis(label, cType = "") {
    if (cType === "") {
      if (this._Axis.YAxis.indexOf(label) === -1) {
        if (
          (this.data.type.toLowerCase() === "pie" ||
            this.data.type.toLowerCase() === "doughnut") &&
          this._Axis.YAxis.length >= 0
        ) {
          this._Axis.YAxis = [];
          this._Axis.YAxis.push(label);
          this.getAggregateDataSource();
        } else {
          this.ChartStyle.color.push("#dd4b39");
          this.ChartStyle.borderColor.push("#dd4b39");
          this._Axis.YAxis.push(label);
        }
      }
    } else if (cType === "bar") {
      if (this._Axis.YAxisBar.indexOf(label) === -1) {
        this.ChartStyle.colorBar.push("#dd4b39");
        this.ChartStyle.borderColorBar.push("#dd4b39");
        this._Axis.YAxisBar.push(label);
      }
    } else if (cType === "line") {
      if (this._Axis.YAxisLine.indexOf(label) === -1) {
        this.ChartStyle.colorLine.push("#dd4b39");
        this.ChartStyle.borderColorLine.push("#dd4b39");
        this._Axis.YAxisLine.push(label);
      }
    }
  }
  //#endregion
  //#region Add Column to table
  public asignColumn(label) {
    if (this._Table.Column.indexOf(label) === -1) {
      this._Table.Column.push(label);
    }
  }
  //#endregion
  ngOnInit() {
    this.getChartsForReports();
  }
  //#region Remove Color/ Assign Values to Y-Axis
  removeYAxis(idx: number, cType = "") {
    if (cType === "") {
      this._Axis.YAxis.splice(idx, 1);
    } else if (cType === "bar") {
      this._Axis.YAxisBar.splice(idx, 1);
    } else if (cType === "line") {
      this._Axis.YAxisLine.splice(idx, 1);
    }
  }
  //#endregion
  //#region Remove Column to table
  removeColumn(idx: number) {
    this._Table.Column.splice(idx, 1);
  }
  //#endregion

  //#region open pop up to Show Data Source Details
  openDataSourceDialog(): void {
    const dialogRef = this.dialog.open(TableModalComponent, {
      width: "400px",
      data: {
        heading: "Data Source",
        result: this.dataSourceResultArray
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Manage Response from modal
      }
    });
  }
  //#endregion

  //#region Reset Configuration
  reset(): void {
    // Reset the Chart Configuration
    this.data.type = "";
    this.EditChartConfig = null;
    this.dataSourceId = undefined;
    this.dataSourceResultArray = [];
    this._Axis = new Axis();
    this._Table = new Table();
    this._DataSource = new DataSource();
    this.color = "red";
    this.Heading = "";
    this.Description = "";
    this.right = "left";
    this.ChartStyle = new Styles();
    this.selectedChart = "";
    jQuery(".tabs").removeClass("active");
    jQuery(".charts-tab").addClass("active");
    jQuery(".tab-pane")
      .removeClass("active")
      .removeClass("in");
    jQuery("#home").addClass("active");
    jQuery("#home").addClass("in");
    // End
  }
  //#endregion

  //#region Set Configuration
  setEditConfiguration() {
    this.dataSourceId = this.EditChartConfig.DataSource.SourceId;
    this.dataSourceResultArray = this.EditChartConfig.DataSource.DataSet;
    this._Axis = this.EditChartConfig.Axis;
    this._Table = this.EditChartConfig.Table;
    this._DataSource = this.EditChartConfig.DataSource;
    this.color = "red";
    this.Heading = this.EditChartConfig.Heading;
    this.Description = this.EditChartConfig.Description;
    this.right = "left";
    this.ChartStyle = this.EditChartConfig.Styles;
    this.selectedChart = this.EditChartConfig.Name;
    this.data.type = this.EditChartConfig.Name.toLowerCase();
    this.legend = this.EditChartConfig.Legend;
    this.ID = this.EditChartConfig.ID;
    debugger;
    this.selectedChartConfiguration =
      ChartConfigurationModel.Configuration[this.selectedChart];
    this.OpenChartConfigurationModal(this.selectedChart);
  }
  //#endregion

  async getAggregateDataSource() {
    debugger;
    var query =
      "Select [tt].[" + this._Axis.XAxis + "] as '" + this._Axis.XAxis + "'";
    this._Axis.YAxis.forEach(element => {
      query +=
        ", " +
        this._Axis.AggregateType +
        "([tt].[" +
        element +
        "]) as '" +
        element +
        "'";
    });
    query +=
      " From [" +
      this._DataSource.Domain +
      "].[" +
      this._DataSource.Query +
      "] as tt";
    query += " Group by [tt].[" + this._Axis.XAxis + "]";

    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        debugger;
        this._DataSource.DataSet = data;
        this.ChartStyle.color = [];
        this._DataSource.DataSet.filter(element => {
          this.ChartStyle.color.push("#dd4b39");
        });
      },
      error => {
        console.log(error);
      }
    );
  }

  openSideSettings() {
    var element = document.body.className;
    // alert();
    if (element.indexOf("settings-open") > -1) {
      document.body.className = "";
    } else {
      document.body.className = document.body.className + " settings-open";
    }
  }
}
