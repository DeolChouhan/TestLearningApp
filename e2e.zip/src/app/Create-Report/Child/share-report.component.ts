import { AnixService } from './../../Service/Anix.Service';
import { Report } from "./../../Model/report.model";
import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: "app-share-model",
  templateUrl: "./share-report.component.html",
  providers: [
    ]
})
export class ShareReportModalComponent implements OnInit {
  public btnText = "Share Report";
  public headingText = "Share Report";
  public UserArray :any;
  public UserID = 0;
  public View = true;
  public Edit = false;
  public Delete = false;
  public id=0;
  constructor(
    public dialogRef: MatDialogRef<ShareReportModalComponent>,
    @Inject(MAT_DIALOG_DATA) public Report: any,
    private _anixService: AnixService,
    private _toastr: ToastrService,
    private router: Router
  ) {
    this.getUserList();
    if(this.Report.cinchyid && this.Report.cinchyid>0){
      this.id = this.Report.cinchyid;
      this.UserID = this.Report.UserID
      this.Edit = this.Report.Edit === "Yes" ? true : false;
      this.Delete = this.Report.Delete === "Yes" ? true : false;
      this.View = this.Report.View === "Yes" ? true : false;
    }
  }

  //#region Create Report
  onNoClick(): void {
    this.dialogRef.close();
  }
  //#end region

  //#region Chart basic configuration
  onAddClick(): void {
    this.shareReports();
  }

  //#region Get User List
  async getUserList() {
    let query = `SELECT [ID] as ID,[FIRST_NAME] as Name
    FROM [Users]`;
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        this.UserArray = data;
             },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion

  //#region Share Reports
  async shareReports() {
    try {
      let view = this.View //=== true ? "Y" : "N";
      let edit = this.Edit //=== true ? "Y" : "N";
      let _delete = this.Delete //=== true ? "Y" : "N";

      let query
      if(this.id ===0){
          query = `Insert into UserReportsShared ([UserReport Id],[User],[View],[Edit],[Delete],[Active])
        values(${this.Report.ID},
          ${this.UserID},'${view}',
        '${edit}','${_delete}',1)`;
      }
      else{
        query = `update UserReportsShared set [UserReport Id]='${this.Report.ID}',
        [User]='${this.UserID}',[View]='${view}',[Edit]='${edit}',[Delete]='${_delete}'
        where [id]='${this.id}'`;
      }

      this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
        data => {
          this._toastr.success("Report Shared Successfully.", "Success");
          this.dialogRef.close();
               },
        error => {
          console.log(error);
        }
      );

    } catch (e) {
      this._toastr.error("Error Occur while sharing report.", "Error");
      console.log(e);
    }
  }
  //#endregion

  ngOnInit() {}
}
