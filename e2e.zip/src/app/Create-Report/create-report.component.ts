import { AnixService } from "./../Service/Anix.Service";
import { Component } from "@angular/core";
import { CreateReportModalComponent } from "../Create-Report-Modal/create-report-modal.component";
import { MatDialog } from "@angular/material";
import { environment } from "src/environments/environment";
import { IReport, Report } from "../Model/report.model";
import { Router } from "@angular/router";
import { IChart } from "../Model/chart.model";
import { ITabs } from "../Model/tabs.model";
import { ConfirmationDialogComponent } from "../confirmation-dialog/confirmation-dialog.component";
import { ToastrService } from "ngx-toastr";
import { ShareReportModalComponent } from "./Child/share-report.component";
declare const jQuery: any;
@Component({
  selector: "app-report-create",
  templateUrl: "./create-report.component.html",
  styleUrls: ["./create-report.component.css"],
  providers: [
  ]
})
export class CreateReportComponent {
  public dataSaveReports: any = [];
  userID;
  searchText: "";
  constructor(
    public dialog: MatDialog,
    private _toastr: ToastrService,
    private _anixService: AnixService,
    private router: Router
  ) {}
  ngOnInit() {
    this.userID = 1;
    this.getSavedReports();
    // this..login().then(response => {
    //   this..getUserIdentity().subscribe(
    //     userId => {
    //       if (userId != null) {
    //         this.userID = userId["id"];
    //         this.getSavedReports();
    //       }
    //     }
    //   );
    // }).catch(error => {
    //   console.error('Login Failed');
    // });
    jQuery(document).ready(function($) {
      $(".burger-menu").on("click", "a", function() {
        $(".profile-bar")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("left-expand");
      });

      $(".burger-menu1").on("click", "a", function() {
        $(".chart-slide")
          .toggleClass("open")
          .siblings()
          .removeClass("open");
        $(".main-container").toggleClass("right-expand");
      });
    });
  }
  //#region open pop up to add/Create Reports
  openCreateReportDialog(): void {
    const dialogRef = this.dialog.open(CreateReportModalComponent, {
      width: "400px",
      data: ""
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      }
    });
  }
  //#endregion
  //#region Get saved reports
  async getSavedReports() {
    let query = `SELECT [ID] as ID, [Name] as Name, [Favourite] as Favourites
      FROM [dbo].[UserReports]
        WHERE [Active]= 1 and [Created By]='${this.userID}' ORDER BY 1 desc`;
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        this.dataSaveReports = data;
      },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion
  //#region Get edit reports
  async EditReport(id, type: number) {
    let data: Array<IChart> = [];
    let mTabs: Array<ITabs> = [];
    let query = `Select ID as ID,Sequence as Sequence, Name as TabName from UserReportTabs where [UserReport ID] = ${id}`;
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      (response: any) => {
        response.forEach(element => {
          mTabs.push({
            cinchyid: element.ID.toString(),
            ID: element.Sequence.toString(),
            TabName: element.TabName
          });
        });
        this.getReportBYID(id, type, mTabs);
      },
      error => {}
    );
  }

  async getReportBYID(id, type: number, mTabs: any) {
    let query = `Select ID as ID, Name as Name,JSON as JSON from UserReports where [ID] = ${id}`;
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      (response: any) => {
        debugger;
        if (response.length > 0) {
          let report: IReport = new Report(
            response[0].ID,
            response[0].Name,
            "",
            0,
            response[0].JSON
          );
          localStorage.setItem("ReportData", JSON.stringify(report));
          localStorage.setItem("ReportTabsData", JSON.stringify(mTabs));
          if (type === 0) {
            this.router.navigateByUrl("/manage-report");
          } else {
            this.router.navigateByUrl("/view-report");
          }
        }
      },
      error => {}
    );
  }

  //#endregion

  //#region delete report
  DeleteReport(id): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: "400px",
      data: {
        ID: id,
        Type: "Report"
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.getSavedReports();
    });
  }
  //#endregion
  //#region mark favourite
  async MarkFavourite(id) {
    let query1 = `Update UserReports set [Favourite] = 1 where [ID]= '${id}'`;
    this._anixService.ExecuteSql(environment.Database,query1, null).subscribe(
      response => {
        this._toastr.success(
          "Report added to favourites successfully.",
          "Success"
        );
        this.getSavedReports();
      },
      error => {
        this._toastr.error("Error Occur while saving report.", "Error");
        return;
      }
    );
  }
  //#endregion
  //#region unmark favourite
  async UnmarkFavourite(id) {
    let query1 = `Update UserReports set [Favourite] = 0 where [Id]= '${id}'`;
    this._anixService.ExecuteSql(environment.Database,query1, null).subscribe(
      response => {
        this._toastr.success(
          "Report remove from favourites successfully.",
          "Success"
        );
        this.getSavedReports();
      },
      error => {
        this._toastr.error("Error Occur while saving report.", "Error");
        return;
      }
    );
  }
  //#endregion

  //#region open pop up to add/Create Reports
  openShareReportDialog(report): void {
    const dialogRef = this.dialog.open(ShareReportModalComponent, {
      width: "400px",
      data: report
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
      }
    });
  }
  //#endregion
}
