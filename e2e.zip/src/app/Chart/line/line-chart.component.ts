import { AnixService } from "./../../Service/Anix.Service";
import { IChart } from "./../../Model/chart.model";
import { Component, OnInit, Inject, Input } from "@angular/core";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
@Component({
  selector: "app-line-chart",
  templateUrl: "./line-chart.component.html",
  providers: [
  ]
})
export class LineChartComponent implements OnInit {
  public dataSetArray: any = [];
  @Input("Configuration")
  Configuration: IChart;

  //#region Chart basic configuration
  public lineChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      position: "top",
      labels: {
        fontSize: 12,
        fontColor: "black"
      }
    },
    scales: {
      yAxes: [
        {
          display: true,
          weight: 5,
          ticks: {
            min: 0,
            fontSize: 10,
            fontColor: "black"
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ],
      xAxes: [
        {
          display: true,
          ticks: {
            min: 0,
            fontSize: 10,
            fontColor: "black"
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ]
    }
  };
  public lineChartLabels = [];
  public lineChartType = "line";
  public lineChartLegend = true;
  public lineChartData = [];
  public chartColors: Array<any> = [];
  //#endregion
  constructor(
    private _anixService: AnixService
  ) {
    // this.getDataSource();
  }
  ngOnChanges() {
    this.configureChart();
  }


  async configureChart() {
    //data source aggreigate functionality
    var query =
      "Select [tt].[" +
      this.Configuration.Axis.XAxis +
      "] as '" +
      this.Configuration.Axis.XAxis +
      "'";
    this.Configuration.Axis.YAxis.forEach(element => {
      query +=
        ", " +
        this.Configuration.Axis.AggregateType +
        "([tt].[" +
        element +
        "]) as '" +
        element +
        "'";
    });
    query +=
      " From [" +
      this.Configuration.DataSource.Domain +
      "].[" +
      this.Configuration.DataSource.Query +
      "] as tt";
    query += " Group by [tt].[" + this.Configuration.Axis.XAxis + "]";


    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        debugger;
        this.Configuration.DataSource.DataSet = data;
        // push Label X-Axis
        this.Configuration.DataSource.DataSet.filter(element => {
          this.lineChartLabels.push(element[this.Configuration.Axis.XAxis]);
        });
        // push data Y-Axis
        let i = 0;
        this.Configuration.Axis.YAxis.forEach(yelement => {
          let dataSet = {
            label: "",
            data: [],
            backgroundColor: "",
            borderColor: "",
            borderWidth: 2,
            fill: this.Configuration.Styles.fill
          };
          this.Configuration.DataSource.DataSet.filter(element => {
            dataSet.data.push(element[yelement]);
          });
          // configure Legend
          dataSet.label = yelement;
          dataSet.backgroundColor = this.Configuration.Styles.color[i];
          dataSet.borderColor = this.Configuration.Styles.color[i];
          dataSet.borderWidth = this.Configuration.Styles.borderWidth;
          i = i + 1;
          //Push Object of DataSet to dataSets
          this.lineChartData.push(dataSet);
          this.lineChartLegend = this.Configuration.Legend.Legend;
          this.lineChartOptions.legend.position = this.Configuration.Legend.LegendPosition;
          this.lineChartOptions.legend.labels.fontColor = this.Configuration.Legend.LegendColor;
          this.lineChartOptions.legend.labels.fontSize = this.Configuration.Legend.LegendFontSize;
          this.lineChartOptions.scales.xAxes[0].display = this.Configuration.Axis.XAxisDisplay;
          this.lineChartOptions.scales.yAxes[0].display = this.Configuration.Axis.YAxisDisplay;
          this.lineChartOptions.scales.yAxes[0].ticks.fontColor = this.Configuration.Axis.YAxisFontColor;
          this.lineChartOptions.scales.xAxes[0].ticks.fontColor = this.Configuration.Axis.XAxisFontColor;
          this.lineChartOptions.scales.yAxes[0].ticks.fontSize = this.Configuration.Axis.YAxisFontSize;
          this.lineChartOptions.scales.xAxes[0].ticks.fontSize = this.Configuration.Axis.XAxisFontSize;
        });
      },
      error => {
        console.log(error);
      }
    );
  }
  ngOnInit() {}
}
