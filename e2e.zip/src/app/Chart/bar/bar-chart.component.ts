import { AnixService } from "./../../Service/Anix.Service";
import { IChart } from "./../../Model/chart.model";
import { Component, OnInit, Inject, Input } from "@angular/core";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
@Component({
  selector: "app-bar-chart",
  templateUrl: "./bar-chart.component.html",
  providers: [
  ]
})
export class BarChartComponent implements OnInit {
  public dataSetArray: any = [];
  @Input("Configuration")
  Configuration: IChart;

  //#region Chart basic configuration
  public barChartOptions = {
    scaleShowVerticalbars: false,
    responsive: true,
    legend: {
      position: "left",
      labels: {
        fontSize: 12,
        fontColor: "black"
      }
    },
    scales: {
      yAxes: [
        {
          display: true,
          stacked: false,
          weight: 5,
          ticks: {
            min: 0,
            fontSize: 10,
            fontColor: "black"
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ],
      xAxes: [
        {
          display: true,
          stacked: false,
          ticks: {
            min: 0,
            fontSize: 10,
            fontColor: "black"
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ]
    }
  };
  public barChartLabels = [];
  public barChartType = "bar";
  public barChartLegend = true;
  public barChartData = [];
  public chartColors: Array<any> = [];
  //#endregion

  constructor(
    private _anixService: AnixService
  ) {
    // this.getDataSource();
  }
  ngOnChanges() {
    this.configureChart();
  }


  async configureChart() {
    //data source aggreigate functionality
    var query =
      "Select [tt].[" +
      this.Configuration.Axis.XAxis +
      "] as '" +
      this.Configuration.Axis.XAxis +
      "'";
    this.Configuration.Axis.YAxis.forEach(element => {
      query +=
        ", " +
        this.Configuration.Axis.AggregateType +
        "([tt].[" +
        element +
        "]) as '" +
        element +
        "'";
    });
    query +=
      " From [" +
      this.Configuration.DataSource.Domain +
      "].[" +
      this.Configuration.DataSource.Query +
      "] as tt";
    query += " Group by [tt].[" + this.Configuration.Axis.XAxis + "]";

    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        debugger;
        this.Configuration.DataSource.DataSet = data;
        // push Label X-Axis
        this.Configuration.DataSource.DataSet.filter(element => {
          this.barChartLabels.push(element[this.Configuration.Axis.XAxis]);
        });
        // push data Y-Axis
        let i = 0;
        this.Configuration.Axis.YAxis.forEach(yelement => {
          let dataSet = {
            label: "",
            data: [],
            backgroundColor: [],
            borderColor: [],
            borderWidth: [],
            fill: this.Configuration.Styles.fill
          };
          this.Configuration.DataSource.DataSet.filter(element => {
            dataSet.data.push(element[yelement]);
            dataSet.backgroundColor.push(this.Configuration.Styles.color[i]);
            dataSet.borderColor.push(this.Configuration.Styles.borderColor[i]);
            dataSet.borderWidth.push(this.Configuration.Styles.borderWidth);
          });
          // configure Legend
          dataSet.label = yelement;
          i = i + 1;
          // Push Object of DataSet to dataSets
          this.barChartData.push(dataSet);
          this.barChartLegend = this.Configuration.Legend.Legend;
          // Options Configuration
          this.barChartOptions.legend.position = this.Configuration.Legend.LegendPosition;
          this.barChartOptions.legend.labels.fontColor = this.Configuration.Legend.LegendColor;
          this.barChartOptions.legend.labels.fontSize = this.Configuration.Legend.LegendFontSize;
          this.barChartOptions.scales.xAxes[0].display = this.Configuration.Axis.XAxisDisplay;
          this.barChartOptions.scales.yAxes[0].display = this.Configuration.Axis.YAxisDisplay;
          this.barChartOptions.scales.yAxes[0].ticks.fontColor = this.Configuration.Axis.YAxisFontColor;
          this.barChartOptions.scales.xAxes[0].ticks.fontColor = this.Configuration.Axis.XAxisFontColor;
          this.barChartOptions.scales.yAxes[0].ticks.fontSize = this.Configuration.Axis.YAxisFontSize;
          this.barChartOptions.scales.xAxes[0].ticks.fontSize = this.Configuration.Axis.XAxisFontSize;
        });
        this.barChartOptions.scales.xAxes[0].stacked = this.Configuration.Axis.xAxisStack;
        this.barChartOptions.scales.yAxes[0].stacked = this.Configuration.Axis.yAxisStack;
      },
      error => {
        console.log(error);
      }
    );
  }
  ngOnInit() {}
}
