import { IChart } from "./../../Model/chart.model";
import { Component, OnInit, Inject, Input } from "@angular/core";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
import { AnixService } from "src/app/Service/Anix.Service";
@Component({
  selector: "app-pie-chart",
  templateUrl: "./pie-chart.component.html",
  providers: [
  ]
})
export class PieChartComponent implements OnInit {
  public dataSetArray: any = [];
  @Input("Configuration")
  Configuration: IChart;

  //#region Chart basic configuration
  public pieChartLabels = [];
  public pieChartData = [];
  public pieChartType = "pie";
  public pieChartLegend = true;
  public options: any = {
    legend: {
      position: "top",
      labels: {
        fontSize: 12,
        fontColor: "black"
      }
    }
  };
  public chartColors: Array<any> = [];
  //#endregion
  constructor(
    private _anixService: AnixService
  ) {}
  ngOnChanges() {
    this.configureChart();
  }

  async configureChart() {
    //data source aggreigate functionality
    var query =
      "Select [tt].[" +
      this.Configuration.Axis.XAxis +
      "] as '" +
      this.Configuration.Axis.XAxis +
      "'";
    this.Configuration.Axis.YAxis.forEach(element => {
      query +=
        ", " +
        this.Configuration.Axis.AggregateType +
        "([tt].[" +
        element +
        "]) as '" +
        element +
        "'";
    });
    query +=
      " From [" +
      this.Configuration.DataSource.Domain +
      "].[" +
      this.Configuration.DataSource.Query +
      "] as tt";
    query += " Group by [tt].[" + this.Configuration.Axis.XAxis + "]";
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        debugger;
        this.Configuration.DataSource.DataSet = data;
        // push Label X-Axis
        this.Configuration.DataSource.DataSet.filter(element => {
          this.pieChartLabels.push(element[this.Configuration.Axis.XAxis]);
        });
        // push data Y-Axis
        this.Configuration.Axis.YAxis.forEach(yelement => {
          this.Configuration.DataSource.DataSet.filter(element => {
            this.pieChartData.push(element[yelement]);
          });
          // configure Legend
        });
        this.pieChartLegend = this.Configuration.Legend.Legend;
        this.options.legend.position = this.Configuration.Legend.LegendPosition;
        this.options.legend.labels.fontColor = this.Configuration.Legend.LegendColor;
        this.options.legend.labels.fontSize = this.Configuration.Legend.LegendFontSize;
        this.chartColors.push({
          backgroundColor: this.Configuration.Styles.color
        });
      },
      error => {
        console.log(error);
      }
    );
  }
  ngOnInit() {}
}
