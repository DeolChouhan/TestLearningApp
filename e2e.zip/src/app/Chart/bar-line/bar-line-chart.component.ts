import { IChart } from '../../Model/chart.model';
import { Component, OnInit, Inject, Input } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { environment } from 'src/environments/environment';
import { AnixService } from "./../../Service/Anix.Service";
@Component({
  selector: 'app-bar-line-chart',
  templateUrl: './bar-line-chart.component.html',
  providers: [
  ]
})
export class BarLineChartComponent implements OnInit {
  public dataSetArray: any = [];
  @Input('Configuration')
  Configuration: IChart;

  //#region Chart basic configuration
  public barLineChartOptions = {
    scaleShowVerticalbars: false,
    responsive: true,
    legend: {
      position: 'left',
      labels: {
        fontSize: 12,
        fontColor: 'black'
      }
    },
    scales: {
      yAxes: [
        {
          display: true,
          weight: 5,
          ticks: {
           min: 0,
           fontSize: 10,
           fontColor: 'black'
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ],
      xAxes: [
        {
          display: true,
          ticks: {
            min: 0,
            fontSize: 10,
            fontColor: 'black'
          },
          gridLines: {
            offsetGridLines: false
          }
        }
      ]
    }
  };
  public barLineChartLabels = [];
  public barLineChartType = 'bar';
  public barLineChartLegend = true;
  public barLineChartData = [];
  public chartColors: Array<any> = [];
  //#endregion

  constructor( private _anixService: AnixService) {
    // this.getDataSource();
  }
  ngOnChanges() {
    this.configureChart();
  }

  async configureChart() {
    //data source aggreigate functionality
    var query="Select [tt].[" + this.Configuration.Axis.XAxis +"] as '" + this.Configuration.Axis.XAxis + "'";
    this.Configuration.Axis.YAxisBar.forEach(element => {
      query+= ", "+ this.Configuration.Axis.AggregateType +"([tt].["+ element +"]) as '" + element + "'";
    });
    this.Configuration.Axis.YAxisLine.forEach(element => {
      query+= ", "+ this.Configuration.Axis.AggregateType +"([tt].["+ element +"]) as '" + element + "'";
    });
    query+= " From ["+ this.Configuration.DataSource.Domain +"].["+ this.Configuration.DataSource.Query +"] as tt"
    query+= " Group by [tt].[" + this.Configuration.Axis.XAxis +"]"

      this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
        data => {
          this.Configuration.DataSource.DataSet = data;
          // push Label X-Axis
    this.Configuration.DataSource.DataSet.filter(element => {
      this.barLineChartLabels.push(element[this.Configuration.Axis.XAxis]);
    });
    // push data Y-Axis
    let i = 0;
    this.Configuration.Axis.YAxisBar.forEach(yelement => {
      let dataSet = {
        type:'bar',
        label: '',
        data: [],
        backgroundColor: '',
        borderColor: '',
        borderWidth: 3,
        fill: false //this.Configuration.Styles.fill
      };
      this.Configuration.DataSource.DataSet.filter(element => {
        dataSet.data.push(element[yelement]);
        dataSet.backgroundColor = this.Configuration.Styles.colorBar[i];
        dataSet.borderColor = this.Configuration.Styles.borderColorBar[i];
        dataSet.borderWidth = this.Configuration.Styles.borderWidth;
      });
      // configure Legend
      dataSet.label = yelement;
      i = i + 1;
      // Push Object of DataSet to dataSets
      this.barLineChartData.push(dataSet);
    });
    i = 0;
    this.Configuration.Axis.YAxisLine.forEach(yelement => {
      let dataSet = {
        type:'line',
        label: '',
        data: [],
        backgroundColor: '',
        borderColor: '',
        borderWidth: 3,
        fill: false //this.Configuration.Styles.fill
      };
      this.Configuration.DataSource.DataSet.filter(element => {
        dataSet.data.push(element[yelement]);
        dataSet.backgroundColor = this.Configuration.Styles.colorLine[i];
        dataSet.borderColor = this.Configuration.Styles.borderColorLine[i];
        dataSet.borderWidth = this.Configuration.Styles.borderWidth;
      });
      // configure Legend
      dataSet.label = yelement;
      i = i + 1;
      // Push Object of DataSet to dataSets
      this.barLineChartData.push(dataSet);
    });
    // Options Configuration
    this.barLineChartLegend = this.Configuration.Legend.Legend;
    this.barLineChartOptions.legend.position = this.Configuration.Legend.LegendPosition;
    this.barLineChartOptions.legend.labels.fontColor = this.Configuration.Legend.LegendColor;
    this.barLineChartOptions.legend.labels.fontSize = this.Configuration.Legend.LegendFontSize;
    this.barLineChartOptions.scales.xAxes[0].display = this.Configuration.Axis.XAxisDisplay;
    this.barLineChartOptions.scales.yAxes[0].display = this.Configuration.Axis.YAxisDisplay;
    this.barLineChartOptions.scales.yAxes[0].ticks.fontColor = this.Configuration.Axis.YAxisFontColor;
    this.barLineChartOptions.scales.xAxes[0].ticks.fontColor = this.Configuration.Axis.XAxisFontColor;
    this.barLineChartOptions.scales.yAxes[0].ticks.fontSize = this.Configuration.Axis.YAxisFontSize;
    this.barLineChartOptions.scales.xAxes[0].ticks.fontSize = this.Configuration.Axis.XAxisFontSize;
        },error=>{

        });

  }
  ngOnInit() {}
}
