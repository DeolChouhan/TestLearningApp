import { AnixService } from "./../../Service/Anix.Service";
import { IChart } from "./../../Model/chart.model";
import { Component, OnInit, Inject, Input } from "@angular/core";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-table",
  templateUrl: "./table.component.html",
  providers: [
  ]
})
export class TableComponent implements OnInit {
  public dataSetArray: any = [];
  @Input("Configuration")
  Configuration: IChart;

  //#region Table basic configuration
  public tableHeader = [];
  public tableData = [];
  public tableStyle = "table";
  public headerStyle = "thead-light";
  //#endregion

  constructor(
    private _anixService: AnixService
  ) {
    // this.getDataSource();
  }
  ngOnChanges() {
    this.configureChart();
  }


  async configureChart() {
    //data source aggreigate functionality
    var query = "Select";
    this.Configuration.Table.Column.forEach(element => {
      if (query !== "Select") query += ", ";
      query += " [tt].[" + element + "] as '" + element + "'";
    });
    query +=
      " From [" +
      this.Configuration.DataSource.Domain +
      "].[" +
      this.Configuration.DataSource.Query +
      "] as tt";



    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        console.log(data);
        debugger;
        this.Configuration.DataSource.DataSet = data;
        // push table Header
        let i = 0;
        this.Configuration.Table.Column.forEach(yelement => {
          this.tableHeader.push(yelement);
        });
        this.tableStyle =
          this.Configuration.Table.TableStyle +
          this.Configuration.Table.BorderStyle;
        this.headerStyle = this.Configuration.Table.HeaderStyle;
      },
      error => {
        console.log(error);
      }
    );
  }

  getValue(obj, Header) {
    return obj[Header];
  }
  isArray(arr) {
    if (arr instanceof Array) {
      return true;
    }
    return false;
  }
  ngOnInit() {}
}
