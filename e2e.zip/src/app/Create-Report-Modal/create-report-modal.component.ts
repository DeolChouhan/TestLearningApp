import { AnixService } from './../Service/Anix.Service';
import { Report, IReport } from "./../Model/report.model";
import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { isNullOrUndefined } from "util";
import { environment } from "src/environments/environment";
import { Router } from "@angular/router";
@Component({
  selector: "app-modal",
  templateUrl: "./create-report-modal.component.html",
  providers: [
  ]
})
export class CreateReportModalComponent implements OnInit {
  public btnText = "Create Report";
  public headingText = "Create Report";
  public dataSetArray: any = [];
  public report: IReport = new Report(0, "", "", 0);
  constructor(
    public dialogRef: MatDialogRef<CreateReportModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _anixService: AnixService,
    private router: Router
  ) {
    this.getDataSource();
  }

  //#region Create Report
  onNoClick(): void {
    this.dialogRef.close();
  }
  //#end region

  //#region Chart basic configuration
  onAddClick(): void {
    this.dialogRef.close();
    localStorage.setItem("ReportData", JSON.stringify(this.report));
    this.router.navigateByUrl("/manage-report");
  }

  //#region Get Datasource
  async getDataSource() {
    let query = `Select name as Name, name as ID, 'dbo' as Domain from sys.tables`;
    this._anixService.ExecuteSql(environment.Database, query, null).subscribe(
      data => {
        this.dataSetArray = data;
             },
      error => {
        console.log(error);
      }
    );
  }
  //#endregion
  ngOnInit() {}
}
