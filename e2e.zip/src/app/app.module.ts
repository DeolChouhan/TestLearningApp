import { AnixService } from "./Service/Anix.Service";
import { HttpConfigInterceptor } from "./Service/Interceptor/httpconfig.interceptor";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { AngularDraggableModule } from "angular2-draggable";
import { ReportConfigurationComponent } from "./Report-Configuration/report-configuration.component";
import { CreateReportComponent } from "./Create-Report/create-report.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import {
  MatDialogModule,
  MatFormFieldModule,
  MatButtonModule,
  MatInputModule
} from "@angular/material";
import { CreateReportModalComponent } from "./Create-Report-Modal/create-report-modal.component";
import { NgxSelectModule, INgxSelectOptions } from "ngx-select-ex";
import { FormsModule } from "@angular/forms";
import { DataTableModule } from "angular2-datatable";
import { RightComponent } from "./Report-Configuration/Child/Sidebar/Right/right-sidebar.component";
//import { HeaderConfigurationComponent } from './Report-Configuration/Child/header/header-child.component';
import { LeftComponent } from "./Report-Configuration/Child/Sidebar/Left/left-sidebar.component";
import { ChartConfigurationModalComponent } from "./Chart-Configuration-Modal/chart-configuration-modal.component";
import { KeysPipe } from "./Pipe/columnkey.pipe";
import { DragAndDropModule } from "angular-draggable-droppable";
import { ColorPickerModule } from "ngx-color-picker";
import { LineChartComponent } from "./Chart/line/line-chart.component";
import { ChartsModule } from "ng2-charts";
import { BarChartComponent } from "./Chart/bar/bar-chart.component";
import { PieChartComponent } from "./Chart/pie/pie-chart.component";
import { DoughnutChartComponent } from "./Chart/doughnut/doughnut-chart.component";
import { TableComponent } from "./Chart/table/table.component";
import { MatTabsModule } from "@angular/material/tabs";
import { ExcelService } from "./Service/excel.service";
import { ToastrModule } from "ngx-toastr";
import { TooltipModule } from "ng2-tooltip-directive";
import { ReportViewComponent } from "./report-view/report-view.component";
import { BarLineChartComponent } from "./Chart/bar-line/bar-line-chart.component";
import { ConfirmationDialogComponent } from "./confirmation-dialog/confirmation-dialog.component";
import { FavouritesComponent } from "./favourites/favourites.component";
import { FilterPipe } from "./Pipe/filter.pipe";
import { RecentComponent } from "./recent/recent.component";
import { ShareReportModalComponent } from "./Create-Report/Child/share-report.component";
import { TableModalComponent } from "./table-modal/table-modal.component";
import { UiSwitchModule } from "ngx-toggle-switch";
import { SharedByYouComponent } from "./shared-by-you/shared-by-you.component";
import { SharedWithYouComponent } from "./shared-with-you/shared-with-you.component";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
const CustomSelectOptions: INgxSelectOptions = {
  // Check the interface for more options
  optionValueField: "Id",
  optionTextField: "Name",
  keepSelectedItems: true
};
@NgModule({
  declarations: [
    AppComponent,
    CreateReportComponent,
    ReportConfigurationComponent,
    CreateReportModalComponent,
    // HeaderConfigurationComponent,
    LeftComponent,
    TableModalComponent,
    RightComponent,
    ChartConfigurationModalComponent,
    KeysPipe,
    FilterPipe,
    LineChartComponent,
    BarChartComponent,
    PieChartComponent,
    DoughnutChartComponent,
    TableComponent,
    ReportViewComponent,
    BarLineChartComponent,
    ConfirmationDialogComponent,
    FavouritesComponent,
    RecentComponent,
    ShareReportModalComponent,
    SharedByYouComponent,
    SharedWithYouComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularDraggableModule,
    FormsModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    NgxSelectModule.forRoot(CustomSelectOptions),
    DragAndDropModule,
    ColorPickerModule,
    ChartsModule,
    MatTabsModule,
    DataTableModule,
    TooltipModule,
    UiSwitchModule,
    HttpClientModule,
    ToastrModule.forRoot({
      timeOut: 5000,
      closeButton: true,
      preventDuplicates: true
    })
  ],
  providers: [
    ExcelService,
    AnixService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    CreateReportModalComponent,
    TableModalComponent,
    ConfirmationDialogComponent,
    ShareReportModalComponent
  ]
})
export class AppModule {}
