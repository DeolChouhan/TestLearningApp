import { ReportViewComponent } from './report-view/report-view.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportConfigurationComponent } from './Report-Configuration/report-configuration.component';
import { CreateReportComponent } from './Create-Report/create-report.component';
import { FavouritesComponent } from './favourites/favourites.component';
import { RecentComponent } from './recent/recent.component';
import { SharedByYouComponent } from './shared-by-you/shared-by-you.component';
import { SharedWithYouComponent } from './shared-with-you/shared-with-you.component';
const routes: Routes = [
  { path: '', component: CreateReportComponent },
  { path: 'manage-report', component: ReportConfigurationComponent },
  { path: 'view-report', component: ReportViewComponent },
  { path: 'favourites', component: FavouritesComponent },
  { path: 'reportsharedbyyou', component: SharedByYouComponent },
  { path: 'reportsharedwithyou', component: SharedWithYouComponent },
  { path: 'recent', component: RecentComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'}) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
