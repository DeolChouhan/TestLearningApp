import { Report,IReport } from './../Model/report.model';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-table-modal',
  templateUrl: './table-modal.component.html'
})
export class TableModalComponent implements OnInit {
  public btnText = 'Create Report';
  public headingText = 'Create Report';
  public dataSetArray: any = [];
  public report: IReport = new Report(0,'', '', 0);
  constructor(
    public dialogRef: MatDialogRef<TableModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {

  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  onAddClick(): void {
    this.dialogRef.close();

  }
  ngOnInit() {}
}
